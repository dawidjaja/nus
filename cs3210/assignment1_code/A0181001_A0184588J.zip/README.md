### README

1. Set the number of threads or process in respective file. (N_THREADS or N_PROCS)
2. Run the scripts to test. e.g. `bash script/test-threads.sh`

