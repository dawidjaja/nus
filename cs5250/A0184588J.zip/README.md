To run:
- make
- ./runner < input

